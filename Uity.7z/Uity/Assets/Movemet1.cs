﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movemet1 : MonoBehaviour {

	public float movementSpeed = 5f;
	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {
		transform.Translate(new Vector3( 0f , 0f , Input.GetAxis( "Vertical2" ) ) * 
			Time.deltaTime 
			* movementSpeed);
		transform.Rotate( new Vector3( 0f , Input.GetAxis( "Horizontal2" ) , 0f ) );
	}
}